<?php
session_start();
include_once( 'simple_html_dom.php' );
$keyword=$_GET['keyword'];
$akeyword=urlencode($keyword);
$checkurl='http://baike.baidu.com/item/'.$keyword;
$checkhtml = file_get_html($checkurl);
foreach($checkhtml->find('h1') as $dom2){;}
settype($dom2, 'string');
$x=strlen($dom2);

if ($x!=72)
{
	$html = file_get_html($checkurl);
	echo $html;
}
else
{
echo '相关词条';
for($i=0;$i<=10;$i++)
{
	
	$x=$i*10;
	$searchUrl='http://baike.baidu.com/search/none?word='.$akeyword.'&pn='.strval($x).'&rn=10';
	$html = file_get_html($searchUrl);
	foreach($html->find('a[class=result-title]') as $element)
	       {
	       	$result=$element->href . '<br>'; 
	   		$dom = file_get_html($result);
	   		foreach($dom->find('h1') as $dom2){echo $dom2;}
			echo "<a href=$element->href>进入词条</a>";
	   		}
}
}
?>